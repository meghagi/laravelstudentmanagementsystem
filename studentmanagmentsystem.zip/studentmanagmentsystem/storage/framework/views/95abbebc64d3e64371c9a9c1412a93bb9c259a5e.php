<html>
<head>
<title>Welcome</title>
</head>
<body>Hello world</body>
</html><?php /**PATH C:\xampp\htdocs\studentmanagmentsystem\resources\views/welcome.blade.php ENDPATH**/ ?>