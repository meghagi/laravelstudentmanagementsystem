<html>
<head>
<title>Login Page</title>
 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</head>
<body>

	<div class="container-fluid bg-dark py-3">
		<a href="<?php echo e(url('/login')); ?>" class="text-white"style="font-style: bold; font-size: 20px;">Student curd System</a>
		<a href="<?php echo e(url('/login')); ?>" style="font-style: bold; font-size: 15px; display: inline; margin-left:20px; color:grey;" >Login</a>
		<a href="<?php echo e(url('/reg')); ?>" style="font-style: bold; font-size: 15px; display: inline; margin-left:20px; color:grey;" >Register</a>
	</div>
	<div class="container-fluid bg-light py-3">
		<h1 align="center">Login into your account</h1>

	</div>
    <div class="container">
        <form action="<?php echo e(Route('welcome')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form group">
                <label for="Email">Email</label><br><br>
                <input type="Email" class="form-control" name="Email" placeholder="Enter the name"id="uname">
                <span class="text-danger">
                <?php $__errorArgs = ['Email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                         <?php echo e($message); ?>


                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </span>
            </div>
            <br>
            <div class="form group">
                <label for="Password">Password</label><br><br>
                <input type="password"class="form-control" name="pwd" placeholder="Enter the password"id="pwd">
                <span class="text-danger">
                <?php $__errorArgs = ['pwd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                         <?php echo e($message); ?>


                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </span>
            </div>
            </div>
  	<div class="col-sm-6">
	<div class="form-group">
	 <input type="submit" class="btn bg-primary text-white" name="submit" value="Login"style="margin-left: 110px;">

	</div>	
</form>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\studentmanagmentsystem\resources\views/Login.blade.php ENDPATH**/ ?>